<?php  


$config['num_links'] = 3;
$config['use_page_numbers'] = true;
$config['full_tag_open'] = '<ul>';
$config['full_tag_close'] = '</ul>';
$config['first_link'] = 'First';
$config['first_tag_open'] = '';
$config['first_tag_close'] = '';
$config['last_link'] = 'Last';
$config['last_tag_open'] = '';
$config['last_tag_close'] = '';
$config['next_link'] = '&gt;';
$config['next_tag_open'] = '';
$config['next_tag_close'] = '';
$config['prev_link'] = '&lt;';
$config['prev_tag_open'] = '';
$config['prev_tag_close'] = '';
$config['cur_tag_open'] = '<b>';
$config['cur_tag_close'] = '</b>';



 ?>